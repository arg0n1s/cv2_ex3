function add_noise(X::Array{Float64,2}, sigma::Float64)
	
    
    @assert size(noisy) == size(X)
	return noisy::Array{Float64,2}
end