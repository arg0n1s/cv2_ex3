function studentt(d, sigma::Float64, alpha::Float64)
    return p::Float64;
end

function grad_studentt(d, sigma::Float64, alpha::Float64)
    return p::::Float64;
end
