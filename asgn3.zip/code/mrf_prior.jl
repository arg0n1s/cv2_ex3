function mrf_nlprior(x::Array{Float64,2}, sigma::Float64, alpha::Float64)

    return p::Float64;
end

function grad_mrf_nlprior(x::Array{Float64,2}, sigma::Float64, alpha::Float64)
    
    return p::Float64;
end