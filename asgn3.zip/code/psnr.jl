function psnr(X::Array{Float64,2}, Y::Array{Float64,2})

	return p::Float64
end